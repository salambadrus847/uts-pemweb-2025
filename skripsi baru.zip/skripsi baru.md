﻿**PENGEMBANGAN SISTEM INFORMASI WEBSITE DESA MENGGUNAKAN METODE WATERFALL UNTUK \
MENINGKATKAN PELAYANAN DIGITAL MASYARAKAT** 

![](Aspose.Words.c39490ea-e8b3-4c4f-a897-c21889b2b907.001.jpeg)

**Dosen Pengampu: Dr.NENDEN SITI FATONAH, S.Si., M.Kom.** 

**Disusun Oleh : Badrus salam (20220803069)** 

**FAKULTAS ILMU KOMPUTER PROGRAM STUDI SISTEM INFORMASI** 

**UNIVERSITAS ESA UNGGUL JAKARTA 2025**

DAFTAR ISI \
ABSTRAK..................................................................................................................... i BAB I PENDAHULUAN............................................................................................. 1 

1. Latar Belakang........................................................................................................ 1 
1. Rumusan Masalah................................................................................................... 2 
1. Tujuan Penelitian .................................................................................................. 2 
1. Manfaat Penelitian  ...................................................................................... 2 
1. Batasan Masalah  .................................................................................................. 3 BAB II TINJAUAN PUSTAKA  .......................................................................... 4 
1. Sistem Informasi Desa  ...................................................................................... 4 
1. Website Desa  .................................................................................................. 5 
1. Metode Waterfall .................................................................................................. 5 
1. Teknologi yang Digunakan  .......................................................................... 6 
1. Penelitian Terdahulu  ...................................................................................... 6 BAB III METODOLOGI PENELITIAN  .............................................................. 7 
1. Jenis dan Pendekatan Penelitian  .......................................................................... 7 
1. Metode Pengembangan Sistem  .......................................................................... 7 
1. Teknik Pengumpulan Data  .......................................................................... 8 
1. Alat dan Bahan  .................................................................................................. 8 
1. Desain Sistem  .................................................................................................. 9 BAB IV HASIL DAN PEMBAHASAN  ............................................................ 10 
1. Analisis Kebutuhan Sistem  ........................................................................ 10 
1. Desain Sistem  ................................................................................................ 11 
1. Implementasi Sistem  .................................................................................... 11 
1. Pengujian Sistem  ................................................................................................ 12 
1. Evaluasi Sistem  ................................................................................................ 13 BAB V PENUTUP  ................................................................................................ 14 
1. Kesimpulan  ................................................................................................ 14 
1. Saran  ............................................................................................................ 15 DAFTAR PUSTAKA ................................................................................................ 16 LAMPIRAN  ............................................................................................................ 17 

ii 
**BAB **ii**** 

**ABSTRAK** 

Abstrak 

Desa  merupakan  salah  satu  desa  yang  tengah  bertransformasi  menuju digitalisasi  pelayanan  publik.  Namun,  keterbatasan  dalam  pengelolaan informasi  dan  pelayanan  administrasi  masyarakat  secara  manual menghambat  efektivitas  pelayanan.  Penelitian  ini  bertujuan  untuk mengembangkan  sistem  informasi  berbasis  website  yang  mampu memfasilitasi  pelayanan  administrasi  desa  secara  digital.  Metode pengembangan yang digunakan adalah Waterfall, yang terdiri dari tahapan analisis kebutuhan, desain sistem, implementasi, pengujian, dan evaluasi. Hasil  pengujian  sistem  menggunakan  metode  blackbox  menunjukkan bahwa seluruh fungsi berjalan sesuai dengan kebutuhan. Evaluasi juga menunjukkan  bahwa  sistem  ini  mampu  meningkatkan  kecepatan, keterbukaan, dan efisiensi pelayanan dibandingkan sistem sebelumnya. Dengan adanya sistem ini, masyarakat dapat mengakses layanan secara daring tanpa harus datang langsung ke kantor desa. Sistem ini diharapkan dapat  mendukung  transformasi  digital  pemerintahan  desa  serta meningkatkan partisipasi dan kepuasan masyarakat terhadap pelayanan publik. 

` `**PENDAHULUAN** 

1. **Latar Belakang** 

Perkembangan teknologi informasi dan komunikasi (TIK) yang pesat saat ini telah menjadi kebutuhan fundamental untuk menunjang kinerja berbagai organisasi, termasuk  instansi  pemerintahan  di  tingkat  desa(Sisilianingsih  et  al.,  2023). Pemanfaatan  TIK,  sering  disebut  *digital  government*,  bertujuan  meningkatkan pelayanan masyarakat dengan menyediakan akses informasi dan layanan yang efektif, juga mendukung kinerja internal organisasi(Sisilianingsih et al., 2023). Keunggulan sistem berbasis web terletak pada aksesibilitasnya yang luas, memungkinkan pengguna mengakses data dari mana saja dan menggunakan beragam perangkat seperti komputer, laptop,  dan  *smartphone*  yang  terhubung  internet(Pamungkas  et  al.,  2025).  Dalam konteks pembangunan desa, peran TIK sangat vital karena memiliki potensi besar untuk meningkatkan kualitas hidup masyarakat dan mendorong pertumbuhan ekonomi berkelanjutan(Mardinata et al., 2023). Kemajuan TIK ini telah memudahkan banyak pekerjaan dan mendorong berbagai institusi untuk beradaptasi.(Awang et al., 2022) 

Meskipun  potensi  TIK  sangat  besar,  banyak  desa  di  Indonesia  masih menghadapi tantangan dalam pengelolaan data dan pelayanan publik karena masih mengandalkan sistem manual. Sebagai contoh, di Pos Pelayanan Terpadu (Posyandu) Desa Sambiharjo, pencatatan data balita masih dilakukan secara manual atau tulis tangan, yang memperlambat proses input, pencarian, monitoring, dan pelaporan(Ali Mulyanto,  2023).  Kondisi  serupa  juga  terjadi  di  Kantor  Desa  Kelesa,  Kabupaten Indragiri Hulu, di mana pengelolaan data kependudukan, termasuk data penduduk dan kartu  keluarga,  masih  menggunakan  *Microsoft  Excel*  atau  metode  manual, menyebabkan  proses  pendataan  dan  pencarian  memakan  waktu  lama  dan  rentan terhadap kesalahan atau kehilangan data(Azis Mahendra & Marsal, 2024). Demikian pula,  pelayanan  administrasi  dan  penyampaian  informasi  di  Desa  Pulau  Pekan, Kabupaten Bungo, masih sering dilakukan secara manual, menghambat kecepatan dan pemerataan  informasi  kepada  masyarakat(Rahmawati  et  al.,  2024).  Di  Desa Sumberkledung, Probolinggo, pelayanan pembuatan dokumen masih konvensional, kurang mempertimbangkan kenyamanan dan kecepatan bagi masyarakat(Anam et al., 2023). Di Desa Banjarsari, informasi desa dan pengumuman masih mengandalkan papan informasi dan ketua RT, sementara pengurusan surat kependudukan seperti SKCK, KTP, dan surat domisili masih dibuat manual menggunakan *Microsoft Word*, 

2 

memperlambat  pelayanan(Basten  &  Ardhiansyah,  2022).  Bahkan,  pengelolaan Anggaran Dana Desa (ADD) di Desa Kambata Tana juga masih bersifat manual, mengakibatkan  kurangnya  transparansi  dan  membutuhkan  waktu  lama  dalam pelaporan(Awang et al., 2022). Tantangan lain yang dihadapi termasuk keterbatasan infrastruktur IT, koneksi internet yang tidak stabil, serta kurangnya pemahaman dan keterampilan teknis di kalangan warga dan aparat desa(Sulistyanto et al., 2022). 

Menanggapi permasalahan ini, perancangan dan implementasi sistem informasi berbasis web menjadi solusi yang relevan dan mendesak. Sistem ini diharapkan dapat memudahkan kader posyandu dalam pencatatan, monitoring, dan pelaporan secara digital(Pamungkas et  al.,  2025),  meningkatkan  efisiensi, akurasi,  dan  aksesibilitas manajemen  data  penduduk(Azis  Mahendra  &  Marsal,  2024),  serta  mempercepat penyebaran informasi dan pelayanan publik di desa(Awang et al., 2022). Digitalisasi pelayanan publik juga bertujuan untuk meningkatkan transparansi dan akuntabilitas pemerintah  desa,  serta  mendorong  partisipasi  aktif  masyarakat  dalam pembangunan(Sulistyanto et al., 2022). 

Metode pengembangan sistem yang banyak digunakan dan dianggap sesuai untuk  proyek  dengan  kebutuhan  spesifikasi  yang  jelas  adalah  metode Waterfall(Pamungkas et al., 2025). Model ini melakukan pendekatan secara sistematis dan  berurutan,  mulai  dari  analisis  kebutuhan,  perancangan  sistem,  implementasi, pengujian,  hingga  pemeliharaan(Ali  Mulyanto,  2023).  Pendekatan  ini  membantu dalam  merencanakan  dan  mengelola  tahapan  pengembangan  secara  terstruktur, terutama  ketika  sistem  informasi  desa  seringkali  mengandung  data  sensitif  yang membutuhkan tingkat keamanan tinggi(Hartatik et al., 2024). 

2. **Rumusan Masalah** 
1. Pengelolaan Data dan Pelayanan yang Masih Manual/Konvensional 
1. Keterbatasan Akses Informasi dan Transparansi Publik 
1. Tantangan Implementasi Transformasi Digital dan E-Government 
3. **Identifikasi Masalah** 

Berbagai permasalahan terkait pengelolaan data dan pelayanan publik di tingkat desa masih banyak ditemukan, terutama dalam konteks adaptasi terhadap perkembangan teknologi informasi. Isu-isu ini menghambat efisiensi kinerja aparat desa dan kualitas layanan kepada masyarakat. Beberapa masalah utama yang teridentifikasi meliputi: 

3 

1. Pencatatan dan Pengelolaan Data yang Manual dan Tidak Efisien 
1. Keterbatasan dan Keterlambatan Penyampaian Informasi Publik 
1. Proses Pelayanan Administrasi yang Memakan Waktu dan Kurang Nyaman 
1. Kurangnya Transparansi dalam Pengelolaan Anggaran Desa 
1. Tantangan  dalam  Transformasi  Digital  (Infrastruktur,  SDM,  dan  Budaya       

Organisasi) 

4. **Manfaat Penelitian** 

Penelitian yang berfokus pada transformasi digital pelayanan publik di tingkat desa dan implementasi sistem informasi berbasis web memberikan berbagai manfaat signifikan. Manfaat ini meluas baik untuk pemerintah desa maupun masyarakat, serta berkontribusi  pada  peningkatan  kualitas  tata  kelola  dan  efisiensi  di  berbagai sektor(Sisilianingsih et al., 2023). 

Berikut adalah manfaat-manfaat utama yang dapat diperoleh: 

1. Peningkatan Efisiensi dan Akurasi Pengelolaan Data 
1. Akses Informasi dan Kualitas Pelayanan Publik yang Lebih Baik 
1. Peningkatan Kapasitas Sumber Daya Manusia dan Inovasi 
1. Pengelolaan Sumber Daya Desa yang Lebih Baik dan Partisipasi Masyarakat 

   5. **Batasan Masalah** 

Penelitian ini difokuskan pada pengembangan sistem informasi untuk pelayanan publik di tingkat desa. Guna memastikan penelitian tetap terarah dan dapat memberikan solusi yang spesifik terhadap permasalahan yang telah diidentifikasi, batasan masalah ditetapkan sebagai berikut: 

1. Penyampaian Informasi Desa (Berita Desa) 
1. Layanan Administrasi Surat-Menyurat 
1. Pengelolaan Data Kependudukan 

**BAB II** 

` `**TINJAUAN PUSTAKA** 

Bab ini menguraikan metodologi penelitian yang digunakan untuk mencapai tujuan penelitian, termasuk pendekatan penelitian, metode pengumpulan data, dan teknik analisis data. Selain itu, bab ini juga akan menjelaskan metode pengembangan sistem yang diterapkan dalam perancangan aplikasi atau sistem informasi. 

1. **Pendekatan Penelitian** 

Penelitian  ini  mengadopsi  pendekatan  kuantitatif  dengan  fokus  pada identifikasi faktor pendorong dan penghambat transformasi digital dalam pelayanan publik(Sisilianingsih et al., 2023). Pengambilan data dilakukan melalui survei *cross- sectional* yang melibatkan sejumlah responden(Sisilianingsih et al., 2023). Beberapa penelitian  terkait  pengembangan  sistem  informasi  juga  menggunakan  pendekatan kualitatif deskriptif untuk mengeksplorasi tantangan dan solusi dalam transformasi digital(Nurlaila Nurlaila et al., 2024). Selain itu, *systematic literature review* juga digunakan  untuk  mengidentifikasi  teori  dan  model  yang  relevan  dari  penelitian sebelumnya(Sisilianingsih et al., 2023). 

2. **Objek dan Responden Penelitian** 

Objek penelitian adalah Aparatur Sipil Negara (ASN) yang bekerja di bagian pelayanan publik dari berbagai instansi pemerintah, termasuk kementerian/lembaga, pemerintah provinsi, pemerintah kabupaten/kota, dan pemerintah desa(Sisilianingsih et al., 2023). Dalam konteks pengembangan sistem informasi desa atau posyandu, objek penelitian mencakup Kader Posyandu dan aparatur desa yang terlibat dalam pelayanan publik(Ali Mulyanto, 2023). 

Pemilihan  responden  dilakukan  menggunakan  metode  purposive  sampling, dengan  kriteria  responden  sebagai  pegawai  pemerintah  yang  melaksanakan  tugas dalam  pelayanan  publik(Sisilianingsih  et  al.,  2023).  Contoh  demografi  responden mencakup  berbagai  rentang  usia,  tingkat  pendidikan,  instansi  kerja  (misalnya Kementerian/Non-Kementerian, Lembaga Negara, Pemerintah Provinsi, Kabupaten, Desa), dan lama pengalaman kerja di pelayanan publik(Sisilianingsih et al., 2023). 

3. **Metode Pengumpulan Data** 

Pengumpulan data dalam penelitian ini dilakukan melalui beberapa metode, 

antara lain: 

1. Survei Kuesioner Daring (*Online Questionnaire Survey*) 

   `  `Kuesioner dibuat menggunakan platform seperti Google Form dan disebarkan melalui  berbagai  media  sosial  (WhatsApp,  Instagram,  Facebook, email)(Sisilianingsih et al., 2023). Pengujian keterbacaan kuesioner dilakukan sebelum  penyebaran  massal  untuk  memastikan  kejelasan  dan ketelitian(Sisilianingsih et al., 2023). 

2. Pengamatan (*Observation*) 

   `  `Peneliti  melakukan  pengamatan  langsung  pada  objek  penelitian,  seperti kegiatan  posyandu  atau  sistem  administrasi  desa  yang  ada,  untuk mengidentifikasi masalah dan kebutuhan(Ali Mulyanto, 2023). 

3. Wawancara (*Interview*) 

   `  `Wawancara dilakukan dengan pihak-pihak terkait (misalnya, Kader Posyandu, perangkat  desa,  sekretaris  desa,  pejabat  pemerintah)  untuk  memperoleh informasi  mendalam  mengenai  permasalahan,  prosedur  yang  berjalan,  dan kebutuhan sistem(Ali Mulyanto, 2023). Wawancara dapat bersifat terstruktur dengan pertanyaan yang telah disiapkan sebelumnya(Hanjalah et al., 2022). 

4. Studi Pustaka (*Literature Study*) 

   `  `Pengumpulan  data  dan  informasi  dilakukan  melalui  penelusuran  berbagai referensi, jurnal ilmiah, buku, dan karya ilmiah lain yang relevan dengan topik penelitian(Azis  Mahendra  &  Marsal,  2024).  Metode  *systematic  literature review* juga digunakan untuk mengidentifikasi teori dan model yang sudah ada(Sisilianingsih et al., 2023). 

5. Dokumentasi 

   `  `Mengumpulkan  data  dari  dokumen  atau  arsip  yang  ada,  seperti  laporan penggunaan dana desa atau data kependudukan manual(Awang et al., 2022). 

6. Pre-test dan Post-test 

   `  `Digunakan dalam kegiatan sosialisasi atau pelatihan untuk mengukur tingkat pemahaman  responden  sebelum  dan  sesudah  intervensi(Sulistyanto  et  al., 2022). 

4. **Metode Analisis Data** 

Untuk analisis data, penelitian ini menggunakan: 

1. Structural Equation Modeling (SEM)  

   `  `Dengan Partial Least Square (PLS-SEM): Metode ini dianggap cocok karena kemampuannya dalam memberikan luaran grafis dan analisis yang didasarkan pada teori, serta relevan untuk menganalisis hubungan antara faktor eksogen dan  endogen(Sisilianingsih  et  al.,  2023).  Pengukuran  dengan  PLS-SEM melibatkan dua komponen, yaitu *inner model* (hubungan antar variabel laten) dan *outer model* (hubungan antara variabel dan indikatornya)(Sisilianingsih et al., 2023). Evaluasi *outer model* meliputi validitas konvergen (nilai *Loading Factor* >0,7), validitas diskriminan (*Average Variance Extracted/AVE* >0,5), reliabilitas komposit (>0,7), dan *Cronbach Alpha* (>0,6)(Sisilianingsih et al., 2023).  Evaluasi  *inner  model*  melibatkan  pemeriksaan  kolinearitas  (*Inner Variant Inflation Factor/VIF* <5) dan *goodness of fit index* (*Standardized Root Mean Square Residual/SRMR* <0,05)(Sisilianingsih et al., 2023). 

2. Pengujian Hipotesis 

   `  `Dilakukan dengan melihat nilai *t-statistik* (>1,96 untuk alpha 5%) dan *p-value* (<0,05)(Sisilianingsih et al., 2023). 

3. Analisis Konten (*Content Analysis*)  

   `  `Digunakan  untuk  mengidentifikasi  tema  dan  pola  dari  data kualitatif(Mardinata et al., 2023). 

5. **Metode Pengembangan Sistem** 

Dalam perancangan dan pengembangan sistem informasi, beberapa penelitian mengadopsi metode Waterfall, yang merupakan model *Software Development Life Cycle*  (SDLC)  tertua  dan  paling  populer(Pamungkas  et  al.,  2025).  Model  ini menyediakan pendekatan sekuensial atau terurut, di mana setiap fase harus diselesaikan sepenuhnya sebelum melangkah ke fase berikutnya(Ali Mulyanto, 2023). 

Tahapan-tahapan umum dalam metode Waterfall meliputi: 

1. Analisis Kebutuhan (*Requirement Analysis and Definition*) 

   `  `Mengumpulkan, menganalisis, dan mendefinisikan kebutuhan sistem secara lengkap dari pengguna. Tahap ini menghasilkan dokumen kebutuhan pengguna (*user requirement*)(Ali Mulyanto, 2023). 

2. Desain Sistem (*System and Software Design*) 

   `  `Menterjemahkan syarat kebutuhan ke dalam perancangan perangkat lunak. Fokus pada struktur data, arsitektur perangkat lunak, representasi antarmuka, dan  detail  prosedural  (algoritma)(Ali  Mulyanto,  2023).  Desain  ini  sering digambarkan menggunakan Unified Modeling Language (UML), termasuk Use Case  Diagram,  Activity  Diagram,  Class  Diagram,  dan  Sequence  Diagram. Perancangan  basis  data  (*database  design*)  juga  dilakukan  pada  tahap  ini, seringkali  menggunakan  Entity  Relationship  Diagram  (ERD)  dan  Logical Record Structure (LRS)(Basten & Ardhiansyah, 2022). 

3. Implementasi dan Pengujian Unit (*Implementation and Unit Testing*) 

   `  `Menerjemahkan  desain  program  ke  dalam  kode  menggunakan  bahasa pemrograman  yang  ditentukan.  Program  kemudian  diuji  secara  unit(Ali Mulyanto, 2023). 

4. Integrasi dan Pengujian Sistem (*Integration and System Testing*) 

   `  `Menggabungkan unit-unit program yang telah diuji dan menguji sistem secara keseluruhan  untuk  memastikan  semua  persyaratan  terpenuhi(Ali  Mulyanto, 2023). 

5. Operasi dan Pemeliharaan (*Operation and Maintenance*) 

   `  `Mengoperasikan program  di  lingkungannya dan melakukan pemeliharaan, seperti  penyesuaian,  perbaikan  kesalahan,  atau  penambahan  fitur  karena adaptasi dengan lingkungan atau kebutuhan baru(Ali Mulyanto, 2023). 

6. **Teknik Pengujian Sistem** 

Pengujian  sistem  merupakan  bagian  krusial  dalam  siklus  pengembangan perangkat lunak untuk memastikan sistem bekerja sesuai harapan. Metode pengujian yang digunakan antara lain: 

1. Black Box Testing 

   `  `Pengujian ini berfokus pada persyaratan fungsional perangkat lunak, dengan mengevaluasi  output  yang  dihasilkan  dari  input  tanpa  melihat  mekanisme internal sistem(Tristianto, 2018). 

2. White Box Testing  

   `  `Pengujian  ini  melengkapi  *Black  Box  Testing*  dengan  menguji  mekanisme internal sistem, termasuk struktur kode(Tristianto, 2018). 

3. Uji Kelayakan (*Feasibility Test*) / *User Acceptance Test (UAT)* / *Mean Opinion Score (MOS)* 

   `  `Dilakukan dengan kuesioner skala Likert kepada responden (pengguna akhir) untuk  menilai  kelayakan  dan  kegunaan  sistem,  dengan  mengukur  tingkat kepuasan dan kemudahan penggunaan(Ali Mulyanto, 2023). 

4. Pengujian Kompatibilitas 

   `  `Memastikan  sistem  dapat  berjalan  pada  berbagai  *browser*  atau lingkungan(Anam et al., 2023). 

7. **Teknologi dan Alat yang Digunakan** 

Dalam implementasi sistem informasi website desa berbasis web, digunakan berbagai teknologi dan alat pendukung untuk membangun dan mengelola sistem agar dapat berjalan secara optimal. Adapun teknologi dan alat yang digunakan antara lain sebagai berikut: 

1. Bahasa Pemrograman 
1. Website ini dikembangkan menggunakan HTML, CSS, dan JavaScript untuk antarmuka pengguna (frontend). 
1. Untuk pengembangan sistem dinamis (backend), digunakan PHP sebagai bahasa pemrograman utama. 
1. Apabila sistem dikembangkan lebih lanjut ke versi mobile, Java/Kotlin untuk Android atau Flutter dapat digunakan. 
2. Basis Data (Database) 
   1. Sistem  menggunakan  MySQL  sebagai  sistem  manajemen  basis  data relasional yang terintegrasi dengan PHP. 
   1. PhpMyAdmin digunakan untuk mempermudah proses pengelolaan basis data melalui antarmuka web. 
3. Kerangka Kerja (Framework) 
1. CodeIgniter dapat digunakan sebagai framework PHP yang ringan dan efisien untuk membangun sistem berbasis MVC (Model-View-Controller). 
1. Untuk prototyping dan pengembangan cepat, dapat pula memanfaatkan PHPRad Classic sebagai generator aplikasi berbasis PHP. 
4. Alat Desain dan Pemodelan 

   Dalam tahap perancangan sistem, digunakan pendekatan UML (Unified Modeling Language) yang mencakup: 

1. Use Case Diagram – untuk mendeskripsikan interaksi pengguna dengan sistem. 
1. Activity Diagram – untuk menggambarkan alur proses layanan. 
1. Class Diagram – untuk pemodelan struktur data dan relasi antar entitas. 
1. Sequence Diagram – untuk menjelaskan urutan interaksi antar komponen. 
5. Platform dan Sistem Informasi Pendukung 
1. Google Sites dapat dimanfaatkan untuk pembuatan prototipe website desa yang bersifat statis atau informatif. 
1. OpenSID merupakan platform sumber terbuka yang dapat dijadikan acuan atau digunakan langsung sebagai sistem informasi desa yang lebih lengkap, termasuk untuk layanan administrasi kependudukan. 
6. Perangkat Lunak Pendukung 
1. XAMPP digunakan sebagai server lokal yang mengintegrasikan Apache, PHP, dan MySQL. 
1. Visual Studio Code (VS Code) sebagai teks editor utama untuk penulisan dan manajemen kode. 
1. Balsamiq digunakan untuk membuat wireframe dan mockup antarmuka sistem pada tahap perancangan awal. 

**BAB III \
METODOLOGI PENELITIAN** 

Penelitian ini dirancang untuk mengembangkan sistem informasi yang relevan dengan isu sosial dan keprofesian dalam Sistem Informasi (SI), khususnya berfokus pada  transformasi  digital  pelayanan  publik.  Sistem  yang  dikembangkan  bertujuan untuk mengoptimalkan proses yang sebelumnya manual, meningkatkan transparansi, serta memastikan aksesibilitas informasi dan layanan bagi masyarakat. 

1. **Fokus Penelitian dan Identifikasi Isu** 

Fokus utama penelitian ini adalah pada Transformasi Digital Pelayanan Publik, sebuah area krusial yang mengintegrasikan teknologi informasi dan komunikasi (TIK) untuk meningkatkan kualitas pelayanan kepada masyarakat(Sisilianingsih et al., 2023). Konsep  *Digital  Government  Transformation*  (DGT)  digunakan  sebagai  landasan teoritis untuk memahami faktor pendorong dan penghambat digitalisasi(Sisilianingsih et al., 2023). 

Identifikasi  isu-isu  yang  mendasari  pengembangan  sistem  ini  diperoleh  melalui penelusuran studi pustaka dan analisis terhadap fenomena pelayanan publik, yang menunjukkan adanya beberapa permasalahan utama: 

1. Proses Manual dan Kurang Efisien 

`   `Banyak  layanan  publik  di  tingkat  desa  atau  Posyandu  masih  mengandalkan pencatatan dan pengelolaan data secara manual(Sisilianingsih et al., 2023). Pendekatan ini  sering  kali  memakan  waktu,  rawan  kesalahan  dalam  penghitungan  data  atau pelaporan, serta menyulitkan proses pencarian informasi(Sisilianingsih et al., 2023). Pengelolaan arsip konvensional juga berisiko tinggi terhadap kehilangan data akibat bencana  alam  atau  hama(Hanjalah  et  al.,  2022).  Begitu  pula  dengan  pengelolaan anggaran  dana  desa  yang  masih  manual,  membutuhkan  waktu  lama  untuk menghasilkan laporan dan kurang transparan(Awang et al., 2022). 

2. Kurangnya Transparansi dan Akuntabilitas 

`   `Distribusi bantuan sosial seringkali menghadapi masalah manipulasi dana akibat kurangnya  pengawasan,  yang  memicu  ketidakpercayaan  masyarakat(Purnia  et  al., 2019). 

3. Kesenjangan Digital dan Literasi Teknologi 

`   `Terjadi disparitas akses internet dan rendahnya literasi digital, terutama di daerah pedesaan  atau  kelompok  masyarakat  dengan  tingkat  pendidikan  terbatas.  Hal  ini menghambat  pemanfaatan  layanan  digital  secara  optimal(Nurlaila  Nurlaila  et  al., 2024). Kurangnya pengetahuan dan kesadaran aparatur desa serta masyarakat dalam memanfaatkan  platform  digital  juga  menjadi  kendala  signifikan(Sulistyanto  et  al., 2022). 

4. Tantangan Implementasi e-Government 

`   `Implementasi  *e-Government*  menghadapi  berbagai  tantangan,  termasuk  alokasi anggaran yang tidak merata di setiap unit kerja, rendahnya literasi teknologi informasi di kalangan pegawai, kurangnya dukungan pejabat, dan infrastruktur jaringan internet yang belum optimal(Nurlaila Nurlaila et al., 2024). 

Berdasarkan  isu-isu  ini,  pengembangan  sistem  informasi  ini  diarahkan  untuk menyediakan solusi berbasis teknologi yang dapat mempermudah proses operasional, meningkatkan akurasi  data, mempercepat  penyampaian informasi, dan mendorong partisipasi masyarakat dalam pelayanan publik. 

2. Metode Pengumpulan Data 

Pengumpulan  data  dalam  penelitian  ini  dilakukan  melalui  pendekatan  campuran, menggabungkan metode kuantitatif dan kualitatif, untuk memperoleh informasi yang mendalam dan relevan: 

1. Observasi (Pengamatan Langsung) 

`   `Peneliti melakukan pengamatan langsung di lokasi objek penelitian, seperti kantor desa  atau  Posyandu.  Observasi  ini  bertujuan  untuk  memahami  alur  kerja, mengidentifikasi proses manual yang berjalan, serta melihat langsung permasalahan yang  timbul  dalam  pelayanan  publik(Ali  Mulyanto,  2023).  Data  yang  diperoleh mencakup  aktivitas  pelayanan  ibu  dan  anak  di  Posyandu,  serta  pengelolaan administrasi  dan  arsip  kependudukan  yang  masih  konvensional  di  kantor desa(Hanjalah et al., 2022). 

2. Wawancara 

`   `Dilakukan  dengan  narasumber  kunci,  seperti  kader  Posyandu,  perangkat  desa, pejabat  pemerintah daerah, atau karyawan instansi  terkait(Nurlaila Nurlaila et  al., 2024). Wawancara bertujuan untuk menggali informasi detail mengenai kebutuhan sistem, tantangan yang dihadapi dalam transformasi digital, serta perspektif pengguna terhadap solusi yang diusulkan(Pamungkas et al., 2025). 

3. Studi Pustaka (Tinjauan Literatur) 

`    `Melibatkan pengumpulan dan analisis literatur dari berbagai sumber, seperti jurnal ilmiah, buku, dan dokumen resmi(Pamungkas et al., 2025). Metode ini esensial untuk membangun  landasan  teoritis,  mengidentifikasi  model  atau  penelitian  sebelumnya yang relevan, dan merumuskan tujuan penelitian secara lebih mendalam(Sisilianingsih et al., 2023). 

4. Survei/Kuesioner 

`   `Digunakan untuk mengumpulkan data kuantitatif dari responden. Kuesioner sering disebarkan secara daring, misalnya menggunakan Google Form. *Purposive sampling* dapat  diterapkan  untuk  memilih  responden  yang  sesuai  dengan  kriteria penelitian(Sisilianingsih  et  al.,  2023).  Kuesioner  juga  digunakan  untuk  menguji kelayakan sistem, seringkali menggunakan skala Likert atau  *Mean Opinion Score* (MOS)(Ali  Mulyanto,  2023).  Sebagai  contoh,  dalam  satu  studi,  208  responden dikumpulkan melalui survei *cross-sectional*(Sisilianingsih et al., 2023). 

5. Hasil Data dan Pembahasan 

3\.2.5.1 Data Demografi Responden Penelitian Transformasi Digital Pelayanan Publik 

Sebuah penelitian tentang faktor transformasi digital pelayanan publik di masa pandemi melibatkan 208 responden, dengan 200 respons yang valid(Sisilianingsih et al., 2023). Data demografi responden adalah sebagai berikut: 

1. Jenis Kelamin: Laki-laki 54,3% (113 responden) dan Perempuan 45,7% (95 responden).  Rasio  ini  sesuai  dengan  rasio  jenis  kelamin  penduduk Indonesia(Sisilianingsih et al., 2023). 
1. Usia:  Distribusi  usia  responden  tertinggi  berada  pada  rentang  30-34  tahun (39,9%),  diikuti  oleh  35-39  tahun  (18,3%)  dan  40-49  tahun (15,4%)(Sisilianingsih et al., 2023). 
1. Tingkat Pendidikan: Sebagian besar responden memiliki jenjang pendidikan Sarjana (D4/S1) sebesar 63,9% (133 responden), diikuti oleh Magister (S2) sebesar 28,4% (59 responden)(Sisilianingsih et al., 2023). 
1. Lembaga/Instansi:  Mayoritas  responden  berasal  dari  Kementerian/Non- Kementerian sebesar 68,3% (142 responden)(Sisilianingsih et al., 2023). 
1. Lama Kerja di Pelayanan Publik: Sebagian besar responden (39,4%) memiliki pengalaman kerja 5-10 tahun di pelayanan publik(Sisilianingsih et al., 2023). 
1. Inovasi Pelayanan Publik Berbasis IT: Sebesar 88,9% responden menyatakan bahwa instansi tempat mereka bekerja telah membuat inovasi pelayanan publik berbasis IT(Sisilianingsih et al., 2023). 
2. Hasil Pengujian Hipotesis Transformasi Digital Pelayanan Publik 

Dalam penelitian yang menganalisis faktor pendorong dan penghambat transformasi digital pelayanan publik(Sisilianingsih et al., 2023), pengujian hipotesis (menggunakan t-statistik dan p-value) menghasilkan kesimpulan sebagai berikut: 

1\.  Hipotesis Ditolak (Tidak Berpengaruh Signifikan): 

- H1: Hambatan Organisasi terhadap Transformasi (OBàTR): Ditolak (t- statistik 0.392, p-value 0.696). Ini menunjukkan hambatan organisasi tidak secara  signifikan  memengaruhi  proses  transformasi  digital  pelayanan 

  publik, kemungkinan karena kondisi pandemi COVID-19 yang memaksa perubahan(Sisilianingsih et al., 2023). 

  1. H2:  Hambatan  Budaya  terhadap  Transformasi  (CBàTR):  Ditolak  (t- statistik 0.299, p-value 0.765). Hambatan budaya juga tidak signifikan memengaruhi transformasi digital, karena budaya organisasi ikut berubah akibat pandemi(Sisilianingsih et al., 2023). 
  1. H4: Kegiatan Manajerial  terhadap Transformasi (MAàTR): Ditolak (t- statistik  0.920,  p-value  0.358).  Kegiatan  manajerial  tidak  signifikan memengaruhi proses transformasi, berbeda dengan penelitian sebelumnya, kemungkinan  karena  perubahan  operasional  dan  manajerial  selama pandemi (misalnya, Work From Home/WFH)(Sisilianingsih et al., 2023). 
  1. H5: Daya Tanggap terhadap Transformasi (RSàTR): Ditolak (t-statistik 0.320, p-value 0.749). Daya tanggap dianggap sebagai hasil peningkatan kualitas  layanan  IT,  bukan  faktor  penentu  keberhasilan transformasi(Sisilianingsih et al., 2023). 
2. Hipotesis Diterima (Berpengaruh Signifikan): 
   1. H3a:  Kegiatan  Manajerial  mengurangi  dampak  Hambatan  Organisasi (MAàOB): Diterima (t-statistik 3.605, p-value 0.000). Kegiatan manajerial dapat mengurangi dampak hambatan organisasi dalam proses transformasi digital(Sisilianingsih et al., 2023). 
   1. H3b:  Kegiatan  Manajerial  mengurangi  dampak  Hambatan  Budaya (MAàCB): Diterima (t-statistik 4.834, p-value 0.000). Kegiatan manajerial dapat mengurangi dampak hambatan budaya dalam proses transformasi digital(Sisilianingsih et al., 2023). 
   1. H6: Profesionalisme terhadap Transformasi (PFàTR): Diterima (t-statistik 2.646, p-value 0.008). Profesionalisme, yang ditunjukkan melalui inovasi, kemampuan sumber daya manusia, dan pengalaman kerja, terbukti secara signifikan  memengaruhi  proses  transformasi  digital  pelayanan publik(Sisilianingsih et al., 2023). 
3. Data Hasil Pengujian Sistem (Black Box Testing dan UAT) 

Beberapa  sumber  menampilkan  hasil  pengujian  sistem  informasi  yang dikembangkan,  umumnya  menggunakan  metode  Black  Box  Testing  (untuk fungsionalitas) dan User Acceptance Testing (UAT) (untuk penerimaan pengguna), dengan hasil sebagai berikut: 

1. Sistem Informasi Pelayanan Posyandu Berbasis Web: 
- Pengujian  Black  Box  menunjukkan  bahwa  semua  skenario  pengujian (misalnya,  klik  tombol,  input  data,  search,  edit)  valid  dan  sesuai harapan(Ali Mulyanto, 2023). 
- Pengujian kelayakan menggunakan skala Likert menunjukkan sistem ini mudah digunakan, tombol bekerja sesuai fungsi, keterangan menu jelas, dan kesinambungan halaman mudah dilakukan. Sistem juga bermanfaat untuk  mencari  informasi,  mengetahui  perkembangan  balita,  dan mempermudah proses tambah/edit/pelaporan data(Ali Mulyanto, 2023). 
- Penelitian  lain  juga  menunjukkan  bahwa  aplikasi  Posyandu  dapat membantu  kader  dan  mempermudah  pencatatan,  monitoring,  dan pelaporan secara digital. Validasi Black Box pada sistem Posyandu Desa Sambiharjo menunjukkan semua pengujian berhasil(Ali Mulyanto, 2023). 
2. Sistem Monitoring dan Evaluasi Pembangunan Pedesaan: Pengujian Black Box Testing menunjukkan bahwa persyaratan sistem telah terpenuhi dan sesuai dengan kebutuhan yang didefinisikan sebelumnya(Tristianto, 2018). 
2. Sistem Informasi Desa (SID) dan Website Desa: 
   1. Website  desa  Bangoan  dan  Tulungrejo  dikembangkan  untuk mempublikasikan  potensi  desa  dan  mengelola  administrasi  secara digital(Rozi et al., 2017). 
   1. Website  Desa  Ponggang  berhasil  dibuat  menggunakan  Google  Sites sebagai  fasilitas  pelayanan  publik,  dan  aparatur  desa  menunjukkan kesadaran  tinggi  serta  kemampuan  mengoperasikan  platform  digital tersebut.  Tingkat  pemahaman  TIK  meningkat  dari  rata-rata  35-40% menjadi  70-80%  setelah  penyuluhan.  Kemampuan  mengoperasikan website  mencapai  rata-rata  80%  setelah  pelatihan(Sulistyanto  et  al., 2022)(Basten & Ardhiansyah, 2022). 
   1. Website Informasi Layanan Desa di Pulau Pekan: Hasil pengujian Black Box  menunjukkan  web  dapat  membantu  pencarian  informasi  dan  data penduduk dengan cepat dan efisien. Rata-rata persentase hasil kuesioner dari pengguna adalah 78%, menunjukkan kelayakan web. 
   1. Aplikasi Administrasi Kependudukan Berbasis Web di Desa Gorowong: Pengujian  menunjukkan  aplikasi  ini  mudah  digunakan  dan  dipahami, memudahkan  input  data  tanpa  harus  datang  ke  kantor  desa,  dan mempermudah proses pelaporan(Hanjalah et al., 2022). 
4. Sistem Informasi Pelayanan Masyarakat Desa (Simpelmase) Berbasis Web: 
   1. Pengujian fungsional dengan Black Box Testing menunjukkan hasil 100% 

      valid(Anam et al., 2023). 

   1. Pengujian  non-fungsional  dengan  Sortsite  menunjukkan  sistem  ini kompatibel di semua browser(Anam et al., 2023). 
   1. Sistem  ini  mempercepat  dan  mengefisienkan  proses  permintaan pelayanan(Anam et al., 2023). 
5. Sistem  Informasi  Pelayanan  Administrasi  Kependudukan  Berbasis  Web (SIPAK): 
   1. Pengujian  Black  Box  menunjukkan  semua  kebutuhan  pengguna terpenuhi(Khaerunnisa et al., 2021). 
   1. Pengujian MOS (Mean Opinion Score) berbasis UAT oleh 5 responden menunjukkan  tingkat  kepuasan  yang  tinggi,  dengan  rata-rata  90-100% menyatakan sistem mudah dioperasikan, menarik, responsif, memudahkan masyarakat dan perangkat desa, cepat, menampilkan data sesuai, tata letak informasi jelas, fitur lengkap, dan informasi mudah dipahami(Khaerunnisa et al., 2021). 
5. Sistem Informasi Pengelolaan Anggaran Dana Desa (ADD) Berbasis Web: 
   1. Sistem  ini  mampu  menghemat  waktu  pengerjaan  oleh  bendahara  desa menjadi  2  menit  4  detik,  dibandingkan  sistem  manual  yang  memakan waktu 8 menit 48 detik(Awang et al., 2022). 
   1. Sistem  ini  menyediakan  informasi  akurat  dan  transparan  mengenai penggunaan dana desa kepada masyarakat(Awang et al., 2022). 
7. Sistem Informasi Desa Kedungturi: Pengujian Black Box Testing menyatakan sistem  berfungsi  sesuai  fungsionalitasnya.  Pengujian  UAT  dengan  10 responden menghasilkan skor rata-rata 82,33%, menyimpulkan sistem layak digunakan dan memberikan banyak manfaat(Hartatik et al., 2024). 
7. Transformasi Digital di Kabupaten Bima (Tantangan): 
- Data menunjukkan tantangan dalam implementasi e-government meliputi alokasi  anggaran  yang  berbeda  di  setiap  OPD,  literasi  pegawai  yang rendah, payung hukum yang lemah, kurangnya grand desain, dan akses internet yang belum optimal(Nurlaila Nurlaila et al., 2024). 
- Tantangan lain termasuk kurangnya dukungan pejabat, kebutuhan akan pemantapan kualitas pelayanan, kurangnya kesadaran masyarakat tentang aplikasi, pengelolaan e-Government yang belum merata, dan minimnya kompetensi media sosial(Nurlaila Nurlaila et al., 2024). 
3. **Analisis dan Perancangan Sistem** 

Proses  analisis  dan  perancangan  sistem  dilakukan  secara  sistematis, menggabungkan identifikasi masalah dengan pemodelan solusi: 

1. Analisis  Kebutuhan  (Requirement  Analysis  and  Definition):  Tahap  ini melibatkan identifikasi kebutuhan fungsional dan non-fungsional dari sistem yang akan dibangun. Data kebutuhan diperoleh dari observasi dan wawancara. Contoh kebutuhan meliputi kemampuan sistem untuk mengelola data kader dan balita, mencatat kegiatan Posyandu, memonitor tumbuh kembang balita, serta menghasilkan laporan digital. Untuk  administrasi  desa,  sistem  harus  mampu  mengelola  data  penduduk,  kartu keluarga,  mutasi,  dan  mencetak  rekap  data.  Sistem  bantuan  sosial  membutuhkan kemampuan koordinasi, kontrol aktivitas organisasi, serta transparansi dana. 
1. Analisis Data (Menggunakan PLS-SEM): Untuk memahami faktor-faktor yang mendorong dan menghambat transformasi digital, penelitian ini dapat menggunakan Structural Equation Modeling (SEM) dengan pendekatan Partial Least Square (PLS- SEM). Analisis ini melibatkan dua komponen utama: 
- Outer  Model:  Menentukan  hubungan  antara  variabel  laten  dan  indikatornya. 

Pengujian dilakukan untuk memastikan validitas konvergen (*Loading Factor* > 0,7), validitas diskriminan (*cross loading factor* dan *Average Variance Extracted* (AVE) > 0,5), dan reliabilitas komposit (*Composite Reliability* (CR) dan *Cronbach Alpha* (CA) > 0,6 atau 0,7). 

- Inner  Model:  Menggambarkan  hubungan  antara  variabel  laten  (endogen  dan 

eksogen). Evaluasi dilakukan untuk melihat koefisien jalur, kolineritas (*Inner Variant Inflation Factor* (VIF) < 5), serta *goodness of fit* (*Standardized Root Mean Square Residual* (SRMR) < 0,05). Pengujian Hipotesis menggunakan nilai t-statistik dan p- value juga dilakukan pada tahap ini untuk menentukan pengaruh antar variabel. 

3. Perancangan Sistem (System and Software Design) 

Desain  arsitektur  perangkat  lunak,  struktur  data,  dan  antarmuka  pengguna dibuat. Alat pemodelan yang digunakan adalah Unified Modeling Language (UML): 

1) Use  Case  Diagram:  Memvisualisasikan  fungsionalitas  utama  sistem  dan interaksi antara aktor (pengguna) dengan sistem. 

   ![](Aspose.Words.c39490ea-e8b3-4c4f-a897-c21889b2b907.002.jpeg)

**Gambar 1. Use case diagram sistem informasi Web Desa** 

2) Activity Diagram: Menggambarkan alur kerja atau proses bisnis dalam sistem. 

   Setelah dibuatkan *Use Case Diagram*, dibuatkan *Activity Diagram* untuk setiap *Use Case* nya: 

1. *Activity Diagram Login* 

![](Aspose.Words.c39490ea-e8b3-4c4f-a897-c21889b2b907.003.png)

**Gambar 2. Activity Diagram Login** Sumber : Peneliti 

Penjelasan : 

Dalam  Aktivitas  *Login*  yang  digambarkan  pada  *diagram* diatas,  Admin  dan  warga  dapat  melakukan  *login*  dengan  cara memasukkan *id* dan *password.*  Kemudian  sistem  akan  melakukan verifikasi, jika berhasil maka akan berhasil *login*, tetapi jika tidak berhasil maka harus melakukan *login* kembali dengan memasukkan *name* dan *password* yang benar. 

2. *Activity Diagram Input Data* 

![](Aspose.Words.c39490ea-e8b3-4c4f-a897-c21889b2b907.004.png)

**Gambar 12. Activity Diagram Input Data** Sumber : Peneliti 

Penjelasan : 

*Diagram*  diatas  menjelaskan  aktifitas  dalam  proses penginputan data. Dimana proses ini hanya dapat dilakukan oleh Admin Web Desa. Admin dapat memilih menu tambah data untuk melakukan *input* baru. Kemudian sistem akan memberikan *form input*,  dan  Admin  akan  mengisi  *form*  tersebut  kemudian menyimpannya.  Data  yang  telah  di  *input*  dan  di  simpan,  akan masuk dan tersimpan dalam *database.* 

3. *Activity Diagram* Melihat *Data* 

![](Aspose.Words.c39490ea-e8b3-4c4f-a897-c21889b2b907.005.png)

**Gambar 13. Activity Diagram Melihat Data** Sumber : Peneliti 

Penjelasan : 

*Diagram* diatas menjelaskan aktifitas dalam proses melihat data warga. Proses ini dapat dilakukan oleh Admin. Dimana adnin dapat  memilih  menu  data  warga,  kemudian  sistem  akan menampilkan seluruh data warga, Admin dapat mengetikkan nama yang akan dicari, kemudian dapat melakukan cetak dokumen jika diperlukan. 

4. *Activity Diagram Izin Surat* 

![](Aspose.Words.c39490ea-e8b3-4c4f-a897-c21889b2b907.006.jpeg)

**Gambar 14 . Activity Diagram Izin Surat** Sumber : Peneliti 

Penjelasan : 

Diagram  diatas  menggambarkan  proses  atau  aktivitas dalam menu izin surat. Admin dapat memberikan izin surat ataupun menolak sesuai dengan ketentuan yang ada di Web. Sistem akan memberikan  *update*  dan  nantinya  warga  akan  dapat  melihat keterangan atau status surat mereka masing – masing. 

5. *Activity Diagram* Mengubah *Data* 

   ![](Aspose.Words.c39490ea-e8b3-4c4f-a897-c21889b2b907.007.jpeg)

   **Gambar 15. Activity Diagram Mengubah Data** Sumber : Peneliti 

Penjelasan : 

*Diagram*  diatas  menjelaskan  aktifitas  dalam  proses mengubah atau *edit* data yang di *input*. Akses ini hanya dimiliki oleh admin saja. Dimana admin dapat masuk ke *menu* data warga, kemudian sistem akan menampilkan seluruh data warga. Pemilik dapat  mengetikkan  nama  warga  yang  dicari,  sistem  akan menampilkan permintaan. Setelah tampil, admin dapat melakukan pengubahan data yang sekira nya salah atau memperbarui data. Setelah itu, data yang telah diubah akan tersimpan dalam *database* dan sistem akan kembali  menampilkan data tadi.  Admin  dapat mengecek perubahan data tersebut. 

6. *Activity Diagram* Menghapus *Data* 

![](Aspose.Words.c39490ea-e8b3-4c4f-a897-c21889b2b907.008.jpeg)

**Gambar 16. Activity Diagram Menghapus Data** Sumber : Peneliti 

Penjelasan : 

*Diagram*  diatas  menjelaskan  aktifitas  dalam  proses menghapus data warga yang di *input*. Akses ini hanya dimiliki oleh admin  saja.  Dimana  admin  dapat  masuk  ke  *menu*  data  warga, kemudian sistem akan menampilkan seluruh data warga. Admin dapat  mengetikkan  nama  warga  yang  dicari,  sistem  akan menampilkan permintaan. Setelah tampil, admin dapat melakukan penghapusan  data.  Setelah  itu,  data  yang  telah  dihapus  akan tersimpan dalam *database* dan sistem akan kembali menampilkan data keseluruhan. Admin dapat mengecek perubahan apakah data tersebut masih tersedia atau tidak. 

7. *Activity Diagram* Cetak Surat 

   ![](Aspose.Words.c39490ea-e8b3-4c4f-a897-c21889b2b907.009.png)

   **Gambar 17. Activity Diagram Cetak Dokumen** Sumber : Peneliti 

Penjelasan : 

*Diagram*  diatas  menjelaskan  aktifitas  dalam  proses mencetak dokumen. Akses cetak dokumen ini dapat  digunakan oleh admin dan dapat masuk ke *menu* data warga, kemudian sistem akan menampilkan seluruh data warga yang tersedia. Admin dapat mengetikkan  nama  yang  akan  dicari,  setelah  itu  sistem  akan menampilkan data yang di minta. Setelah data muncul,  Admin dapat melakukan cetak dokumen jika memang diperlukan. 

8. *Activity Diagram* Keterangan Surat 

   ![](Aspose.Words.c39490ea-e8b3-4c4f-a897-c21889b2b907.010.png)

**Gambar 18 . Activity Diagram Keterangan Ujian** Sumber : Peneliti 

Penjelasan : 

Diagram diatas menjelaskan mengenai proses keterangan surat yang dapat diakses oleh warga. Warga dapat melakukan *login* terlebih dahulu, setelah itu memilih fitur menu status surat, maka sistem akan menampilkan status suratnya. 

9. *Activity Diagram Logout* 

   ![](Aspose.Words.c39490ea-e8b3-4c4f-a897-c21889b2b907.011.png)

**Gambar 19 . Activity Diagram Logout** Sumber : Peneliti 

Penjelasan : 

Diagram  diatas memberikan gambaran mengenai  proses *Logout* pada sistem. Admin dan warga dapat melakukan *logout* pada *website* dengan cara klik menu profil, kemudian sistem akan menampilkan menu profil, dan setelahnya mengklik tombol *logout* yang tersedia, kemudian profil tersebut akan keluar dari *website.* 

3) Class Diagram: Menjelaskan struktur statis sistem, termasuk kelas, atribut, metode, dan hubungannya. 

   ![](Aspose.Words.c39490ea-e8b3-4c4f-a897-c21889b2b907.012.jpeg)

4. **Implementasi Metode Pengembangan Sistem** 

Penelitian ini mengadopsi metode Waterfall sebagai pendekatan utama dalam pengembangan  sistem  informasi(Awang  et  al.,  2022).  Model  ini  dipilih  karena pendekatannya  yang  sistematis,  linier,  dan  terstruktur,  di  mana  setiap  fase  harus diselesaikan  sebelum  berlanjut  ke  fase  berikutnya(Purnia  et  al.,  2019).  Tahapan- tahapan yang diterapkan adalah sebagai berikut: 

1. Analisis  Kebutuhan  (Requirement  Analysis  and  Definition):  Tahap  ini merupakan fondasi, di mana peneliti mengumpulkan dan mendefinisikan kebutuhan sistem  secara  lengkap  dan  detail.  Ini  melibatkan  wawancara  dengan  pemangku kepentingan, observasi langsung terhadap proses yang berjalan, dan studi literatur yang relevan(Khaerunnisa et al., 2021). 
2. Perancangan Sistem  (System  and Software Design):  Kebutuhan yang telah dianalisis pada tahap sebelumnya kemudian diterjemahkan menjadi desain sistem. Ini mencakup  perancangan  arsitektur  perangkat  lunak,  struktur  data,  dan  antarmuka pengguna. Pemodelan menggunakan UML (Use Case, Activity, Class Diagram) dan ERD adalah bagian integral dari tahap ini(Azis Mahendra & Marsal, 2024). 
2. Implementasi dan Pengujian Unit (Implementation and Unit Testing): Desain yang telah disetujui diimplementasikan menjadi kode program. Bahasa pemrograman yang  umum  digunakan  adalah  PHP  dan  dapat  didukung  oleh  *framework*  seperti CodeIgniter. Setiap modul atau unit program diuji secara individual (*unit testing*) untuk memastikan fungsionalitasnya berjalan dengan benar(Ali Mulyanto, 2023). 
2. Integrasi dan Pengujian Sistem (Integration and System Testing): Modul-modul yang telah diuji secara unit kemudian digabungkan untuk membentuk sistem yang utuh.  Pengujian  dilakukan  pada  keseluruhan  sistem  untuk  memastikan  semua komponen berinteraksi dengan baik dan memenuhi persyaratan fungsional. Metode pengujian  yang  umum  digunakan  adalah  Blackbox  Testing,  yang  berfokus  pada fungsionalitas eksternal tanpa melihat struktur internalnya. Selain itu, User Acceptance Test (UAT) juga dapat dilakukan oleh pengguna akhir untuk memverifikasi kelayakan sistem dari perspektif mereka(Hartatik et al., 2024). 

   ![](Aspose.Words.c39490ea-e8b3-4c4f-a897-c21889b2b907.013.png)

**Gambar 2. Metode *Waterfall*** Sumber: Peneliti 

5. Operasi dan Pemeliharaan (Operation and Maintenance): Tahap terakhir ini melibatkan penyebaran dan pengoperasian sistem di lingkungan nyata. Pemeliharaan berkelanjutan  dilakukan  untuk  mengatasi  *bug*,  mengadaptasi  sistem  terhadap perubahan lingkungan (misalnya, sistem operasi baru), atau menambahkan fitur sesuai kebutuhan di masa mendatang(Ali Mulyanto, 2023). 
5. **Implementasi Konsep Isu Sosial & Keprofesian SI** 

Pengembangan  sistem  ini  secara  langsung  mengimplementasikan  berbagai konsep yang berkaitan dengan isu sosial dan keprofesian dalam Sistem Informasi, khususnya dalam mendukung Transformasi Digital Pelayanan Publik(Sisilianingsih et al., 2023). Implementasi konsep dan aturannya adalah sebagai berikut: 

1. Transformasi Digital dan Peningkatan Pelayanan Publik: 
1. Konsep: Transformasi digital mengacu pada pergeseran dari layanan tatap muka ke layanan virtual dengan memanfaatkan TIK, dengan tujuan utama untuk memberikan kemudahan akses informasi dan pelayanan yang lebih efektif kepada masyarakat. Hal ini sejalan dengan arahan pemerintah untuk mempercepat transformasi pelayanan publik(Sisilianingsih et al., 2023). 
1. Implementasi dalam Sistem: Sistem informasi yang dikembangkan, seperti Sistem Informasi Posyandu berbasis web atau Sistem Informasi Pelayanan Masyarakat  Desa  berbasis  web,  secara  langsung  menggantikan  proses manual yang inefisien. Ini memungkinkan masyarakat untuk mengajukan permohonan atau mendapatkan informasi secara daring, tanpa harus datang langsung ke kantor desa, sehingga lebih mudah, cepat, dan terjangkau(Anam et al., 2023). 
2. Transparansi dan Akuntabilitas: 
1. Konsep:  *Good  Governance*  menekankan  tata  kelola  pemerintahan  yang transparan dan akuntabel(Sisilianingsih et al., 2023). Dalam konteks digital, sistem  informasi  diharapkan  dapat  meningkatkan  transparansi  dengan menyediakan akses informasi yang mudah kepada publik(Rozi et al., 2017). 
1. Implementasi dalam Sistem: 
- Aplikasi Bantuan Sosial Terdistribusi berbasis Android dirancang untuk memungkinkan  dinas  sosial  mengontrol  aktivitas  organisasi  serta transparansi  dana  yang  disalurkan,  bahkan  memungkinkan  masyarakat untuk melihat penggunaan dana(Purnia et al., 2019). 
- Sistem Informasi Pengelolaan Anggaran Dana Desa (ADD) berbasis web menyediakan  fitur  laporan  akhir  yang  dapat  diakses  oleh  masyarakat, sehingga  penggunaan  dana  desa  menjadi  lebih  transparan(Awang  et  al., 2022). 
- Website desa membantu dalam mempublikasikan seluruh potensi desa dan informasi  pemerintahan,  mendukung  transparansi  publik(Basten  & Ardhiansyah, 2022). 
3. Efisiensi Operasional dan Pengelolaan Sumber Daya: 
1. Konsep: Sistem informasi dirancang untuk meningkatkan kinerja, mengurangi biaya, dan mendukung proses bisnis yang lebih efektif(Ali Mulyanto, 2023). Ini mencakup digitalisasi dokumen dan peningkatan produktivitas(Rozi et al., 2017). 
1. Implementasi dalam Sistem: 
- Dengan  sistem  informasi  Posyandu,  proses  pengolahan,  pencarian,  dan pelaporan data dapat dilakukan dengan lebih cepat dan akurat, mengurangi beban kerja kader Posyandu(Ali Mulyanto, 2023). 
- Aplikasi  administrasi  kependudukan  desa  membantu  perangkat  desa mengolah  data  dengan  lebih  baik,  cepat,  dan  efisien,  mengatasi  masalah penginputan manual dan kehilangan data(Hanjalah et al., 2022). 
- Sistem pengelolaan anggaran dana desa berbasis web dapat menghemat waktu pengerjaan  bendahara  desa  secara  signifikan  dibandingkan  dengan  sistem manual(Awang et al., 2022). 
4. Pemberdayaan Sumber Daya Manusia dan Literasi Digital: 
1. Konsep: Peningkatan keterampilan sumber daya manusia dan literasi teknologi informasi  merupakan  faktor  pendorong  keberhasilan  transformasi digital(Sisilianingsih et al., 2023). 
1. Implementasi dalam Sistem: 
- Sistem dirancang dengan tampilan yang mudah digunakan dan dipahami, bahkan bagi pengguna yang mungkin memiliki literasi digital terbatas(Hartatik et al., 2024). 
- Program  pelatihan  dan  sosialisasi  penggunaan  platform  digital  (website) diberikan  kepada  aparatur  desa  dan  masyarakat  sebagai  bagian  dari  upaya peningkatan  kapasitas  dan  literasi  digital.  Hal  ini  terbukti  meningkatkan pemahaman  dan  kemampuan  mereka  dalam  mengoperasikan teknologi(Sulistyanto et al., 2022). 
- Penekanan pada profesionalisme, yang mencakup inovasi dan peningkatan keterampilan  SDM,  menjadi  kunci  pendorong  digitalisasi  pelayanan publik(Sisilianingsih et al., 2023). 

3\.5.6  Manajemen Perubahan dan Adaptasi Organisasi: 

1. Konsep:  Transformasi  digital  memerlukan  pergeseran  budaya  dan restrukturisasi organisasi untuk menjadi lebih adaptif dan responsif. Meskipun hambatan  organisasi  dan  budaya  dapat  muncul,  kondisi  yang  memaksa perubahan (misalnya, pandemi) dapat mempercepat adaptasi(Sisilianingsih et al., 2023). 
1. Implementasi  dalam  Sistem:  Sistem  yang  dikembangkan  adalah  respons terhadap kebutuhan mendesak untuk beradaptasi dengan kondisi baru (seperti *social distancing*). Penelitian menunjukkan bahwa kegiatan manajerial dapat mengurangi dampak hambatan organisasi dan budaya, mendukung integrasi sistem baru ke dalam lingkungan kerja(Sisilianingsih et al., 2023). 

32 
**BAB **xxxiii****  

**HASIL DAN PEMBAHASAN** 

1. **Analisis Kebutuhan Sistem** 

Analisis kebutuhan dilakukan untuk menentukan fitur-fitur dan perilaku sistem informasi desa yang dikembangkan, agar dapat menjawab kebutuhan masyarakat dan aparat desa secara digital. Kebutuhan sistem diklasifikasikan menjadi 

dua, yaitu kebutuhan fungsional dan non-fungsional. 

1. Tabel Kebutuhan Fungsional 



|No |Kebutuhan Fungsional |Deskripsi |
| - | - | - |
|1 |Login pengguna |Sistem menyediakan autentikasi untuk admin dan penduduk. |
|2 |Manajemen data penduduk |Admin dapat menambah, mengedit, menghapus, dan menampilkan data penduduk. |
|3 |Pengajuan layanan |Penduduk dapat mengajukan layanan surat secara online. |
|4 |Verifikasi layanan oleh admin |Admin memverifikasi dan memproses pengajuan layanan. |
|5 |Penerbitan surat digital |Sistem menghasilkan dokumen surat secara otomatis dan dapat dicetak. |
|6 |Manajemen berita desa |Admin dapat menambahkan, mengedit, dan menghapus berita desa. |
|7 |Manajemen akun pengguna |Admin dapat mengelola akun pengguna termasuk reset kata sandi. |

2. Tabel Kebutuhan Non Fungsional 



|No |Kebutuhan Non-Fungsional |Deskripsi |
| - | - | - |
|1 |Aksesibilitas |Website dapat diakses melalui perangkat komputer dan smartphone. |
|2 |Keamanan |Sistem menggunakan enkripsi password dan validasi form input. |
|3 |Kinerja |Respon halaman maksimal 3 detik per permintaan. |

33 



|4 |Backup dan Recovery |Database dapat dibackup secara manual oleh admin. |
| - | - | :- |
|5 |Antarmuka User Friendly |UI/UX dirancang agar mudah digunakan oleh semua kalangan. |

2. **Desain Sistem** 

Desain sistem mencakup pemodelan aliran data dan struktur dari sistem yang akan dibangun**.** 

**4.2.1 Rancangan Data Interface** 

1. Halaman login 

![](Aspose.Words.c39490ea-e8b3-4c4f-a897-c21889b2b907.014.jpeg)

2. Data laporan 

34 

![](Aspose.Words.c39490ea-e8b3-4c4f-a897-c21889b2b907.015.jpeg)

3. Info unggah 

   ![](Aspose.Words.c39490ea-e8b3-4c4f-a897-c21889b2b907.016.jpeg)

4. Statistik sosial  

   ![](Aspose.Words.c39490ea-e8b3-4c4f-a897-c21889b2b907.017.jpeg)

5. Logout 

   ![](Aspose.Words.c39490ea-e8b3-4c4f-a897-c21889b2b907.018.jpeg)

3. **Implementasi Sistem** 
1. Login Admin 

![](Aspose.Words.c39490ea-e8b3-4c4f-a897-c21889b2b907.019.jpeg)

2. Data Laporan 

![](Aspose.Words.c39490ea-e8b3-4c4f-a897-c21889b2b907.020.jpeg)

3. Unggah Info 

![](Aspose.Words.c39490ea-e8b3-4c4f-a897-c21889b2b907.021.jpeg)

4\.3.4. Statistik Sosial 

![](Aspose.Words.c39490ea-e8b3-4c4f-a897-c21889b2b907.022.jpeg)

4\.3.5 Login Warga 

![](Aspose.Words.c39490ea-e8b3-4c4f-a897-c21889b2b907.023.jpeg)

4\.3.6. Beranda 

![](Aspose.Words.c39490ea-e8b3-4c4f-a897-c21889b2b907.024.jpeg)

7. Tentang Desa 

![](Aspose.Words.c39490ea-e8b3-4c4f-a897-c21889b2b907.025.jpeg)

8. Berita  

![](Aspose.Words.c39490ea-e8b3-4c4f-a897-c21889b2b907.026.jpeg)

9. Layanan 

![](Aspose.Words.c39490ea-e8b3-4c4f-a897-c21889b2b907.027.jpeg)

1. Isu Sosial 

![](Aspose.Words.c39490ea-e8b3-4c4f-a897-c21889b2b907.028.jpeg)

2. Kontak 

![](Aspose.Words.c39490ea-e8b3-4c4f-a897-c21889b2b907.029.jpeg)

4. **Pengujian Sistem** 

Pengujian sistem dilakukan dengan metode Blackbox Testing, untuk memastikan setiap fungsi berjalan sesuai yang diharapkan. 

4\.4.1 Hasil Pengujian Blackbox 



|NO |Fitur |Input |Output yang Diharapkan |Status |
| - | - | - | - | - |
|1 |Login admin |Username dan Password   |Masuk ke dashboard |Berhasil |
|2 |Login gagal |Password salah |Tampil pesan error |Berhasil |
|3 |Ajukan layanan |From terisi lengkap |Data tersimpan |Berhasil |
|4 |Cetak surat |Setelah di setujui admin |File PDF terunduh |Berhasil |
|5 |Tambahkan berita |Judul + Isi |Muncul di halaman berita |Berhasil |

5. **Evaluasi Sistem** 

Evaluasi dilakukan untuk menilai efektivitas sistem sebelum dan sesudah implementasi website desa. 

1. **Kondisi Sebelum Sistem** 



|**Aspek** |**Sebelum Website Desa** |
| - | - |
|**Pengajuan surat** |**Manual, harus datang ke kantor desa** |
|**Penyebaran informasi** |**Terbatas, melalui papan pengumuman** |
|**Waktu pelayanan** |**>2 hari** |
|**Dokumentasi data** |**Rentan hilang (kertas/manual)** |

2. **Kondisi Setelah Sistem** 



|**Aspek** |**Setelah Website Desa** |
| - | - |
|**Pengajuan surat** |**Online, cukup dari rumah** |
|**Penyebaran informasi** |**Real-time melalui website** |
|**Waktu pelayanan** |**<1 hari (lebih efisien)** |
|**Dokumentasi data** |**Digital dan mudah dicari** |

**BAB V PENUTUP** 

1. **Kesimpulan** 

Berdasarkan hasil dari pengembangan dan pengujian sistem informasi website Desa Badrussalam, dapat disimpulkan bahwa: 

1. Sistem yang dibangun mampu memfasilitasi proses pelayanan administrasi desa seperti pengajuan surat keterangan secara digital. 
1. Penggunaan metode Waterfall mempermudah dalam merancang dan mengimplementasikan sistem secara bertahap dan terstruktur. 
1. Hasil pengujian menggunakan metode blackbox menunjukkan bahwa semua fungsi berjalan dengan baik dan sesuai dengan kebutuhan pengguna. 
1. Sistem informasi ini berhasil meningkatkan efisiensi pelayanan, transparansi, dan kenyamanan masyarakat dalam mengakses layanan desa. 
2. **Saran** 

Untuk pengembangan lebih lanjut, berikut beberapa saran yang dapat dipertimbangkan: 

1. Menambahkan fitur notifikasi otomatis melalui email atau WhatsApp agar pengguna mendapatkan informasi proses layanan secara real-time. 
1. Mengembangkan versi mobile agar akses masyarakat lebih fleksibel melalui perangkat smartphone. 
1. Menyediakan dashboard statistik agar pemerintah desa dapat melihat data pelayanan secara analitis. 
1. Melakukan pelatihan rutin kepada operator/admin desa agar sistem dapat digunakan secara optimal dan berkelanjutan. 

**DAFTAR PUSTAKA** 

(Hartatik et al., 2024)Ali Mulyanto, A. F. S. (2023). Implementasi 

Waterfall Pada Perancangan Sistem Informasi Pelayanan Posyandu Berbasis Web. *Implementasi Waterfall Pada Perancangan Sistem Informasi Pelayanan Posyandu Berbasis Web*, *8*(1), 1–7. 

Anam, C., Susanto, H., Yanto, D., & R.G., F. (2023). Pengembangan 

Sistem Informasi Pelayanan Masyarakat Desa (Simpelmase) Berbasis Web. *JEECOM Journal of Electrical Engineering and Computer*, *5*(2), 310–318. https://doi.org/10.33650/jeecom.v5i2.6966 

Awang, Y. B. R., Hariadi, F., & Leo Lede, P. A. R. (2022). Sistem 

Informasi Pengelolaan Anggaran Dana Desa (Add) Berbasis Web Menggunakan Metode Waterfall Pada Desa Kambata Tana, Sumba Timur. *Jurnal Teknik Informatika Inovatif Wira Wacana*, *1*(2), 64. https://doi.org/10.58300/inovatif-wira-wacana.v1i2.277 

Azis Mahendra, A., & Marsal, A. (2024). Rancang Bangun Sistem 

Informasi Pendataan Penduduk Menggunakan Metode Waterfall (Studi Kasus: Kantor Desa Kelesa Kabupaten Indragiri Hulu). *Jurnal Ilmiah Rekayasa Dan Manajemen Sistem Informasi*, *10*(1), 25–30. 

Basten, I., & Ardhiansyah, M. (2022). Perancangan Sistem Informasi 

Desa Berbasis Web Menggunakan Model Waterfall (Studi Kasus Desa Banjarsari Kabupaten Lebak). *Scientia Sacra: Jurnal Sains, Teknologi, Dan Masyarakat*, *2*(1), 147–156. 

Hanjalah, I., Rahman, A., Sopiyan, M., Fauzi, O., & Saifudin, A. (2022). 

Pengembangan Aplikasi Administrasi Kependudukan Berbasis Web di Kantor Pemerintahan Desa Gorowong menggunakan Metode SDLC dengan Model Waterfall. *Jurnal Informatika Universitas Pamulang*, *7*(1), 211–218. http://openjournal.unpam.ac.id/index.php/informatika 

Hartatik, N., Azizah, N. L., & Busono, S. (2024). Sistem Informasi Desa 

Berbasis Web Dengan Menggunakan Metode Waterfall. *JIPI (Jurnal Ilmiah Penelitian Dan Pembelajaran Informatika)*, *9*(1), 264–271. https://doi.org/10.29100/jipi.v9i1.4428 

Khaerunnisa, N., Maryanto, E., & Chasanah, N. (2021). Sistem Informasi 

Pelayanan Administrasi Kependudukan Berbasis Web Menggunakan Metode Waterfall Di Desa Sidakangen Purbalingga. *Jurnal Ilmu Komputer Dan Informatika*, *1*(2), 99–108. https://doi.org/10.54082/jiki.12 

Mardinata, E., Cahyono, T. D., & Muhammad Rizqi, R. (2023). 

Transformasi Digital Desa Melalui Sistem Informasi Desa (SID): Meningkatkan Kualitas Pelayanan Publik dan Kesejahteraan Masyarakat. *Parta: Jurnal Pengabdian Kepada Masyarakat*, *4*(1), 73–81. https://doi.org/10.38043/parta.v4i1.4402 

Nurlaila Nurlaila, Zuriatin Zuriatin, & Nurhasanah Nurhasanah. (2024). 

Transformasi Digital Pelayanan Publik: Tantangan dan Prospek dalam Implementasi E-Government di Kabupaten Bima. *Public Service and Governance Journal*, *5*(2), 21–37. https://doi.org/10.56444/psgj.v5i2.1468 

Pamungkas, N. P., Setiyawan, M., & Widiati, I. S. (2025). Perancangan 

Sistem Informasi Posyandu Berbasis Web Desa Sambiharjo Dengan Metode Pengembangan Waterfall. *Jurnal Rekayasa Sistem Informasi Dan Teknologi*, *2*(3), 1019–1031. https://doi.org/10.70248/jrsit.v2i3.1824 

Purnia, D. S., Rifai, A., & Rahmatullah, S. (2019). Penerapan Metode 

Waterfall dalam Perancangan Sistem Informasi Aplikasi Bantuan Sosial Berbasis Android. *Seminar Nasional Sains Dan Teknologi 2019*, 1–7. 

Rahmawati, R., Ramadhani, Y., Informasi, S. S., Islam, U., Sultan, N., & 

Jambi, S. (2024). Perancangan Informasi Layanan Desa Berbasis Web Menggunakan PHP dan MYSQL. *Jurnal Pendidikan Tambusai*, *8*, 23184–23190. https://jptam.org/index.php/jptam/article/view/15503%0Ahttps://jpta m.org/index.php/jptam/article/download/15503/11720 

Rozi, F., Listiawan, T., & Hasyim, Y. (2017). Pengembangan Website 

Dan Sistem Informasi Desa Di Kabupaten Tulungagung. *JIPI (Jurnal Ilmiah Penelitian Dan Pembelajaran Informatika)*, *2*(2), 

107–112. https://doi.org/10.29100/jipi.v2i2.366 

Sisilianingsih, S., Purwandari, B., Eitiveni, I., & Purwaningsih, M. 

(2023). Analisis Faktor Transformasi Digital Pelayanan Publik Pemerintah Di Era Pandemi. *Jurnal Teknologi Informasi Dan Ilmu Komputer*, *10*(4), 883–892. https://doi.org/10.25126/jtiik.2024107059 

Sulistyanto, A., Muhamad, P., Dwinarko, D., & Sjafrizal, T. (2022). 

Pemberdayaan dan Pendampingan Masyarakat Desa dalam Transformasi Digital Pelayanan Publik Berbasiskan Website. *Jurnal Pengabdian Masyarakat (Abdira)*, *2*(3), 117–128. https://doi.org/10.31004/abdira.v2i3.173 

Tristianto, C. (2018). Penggunaan Metode Waterfall Untuk 

Pengembangan Sistem Monitoring Dan Evaluasi Pembangunan Pedesaan. *Jurnal Teknologi Informasi ESIT*, *XII*(01), 7–21. 
47 
